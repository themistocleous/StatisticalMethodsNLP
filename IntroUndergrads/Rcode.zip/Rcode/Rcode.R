# Assign PMF values
dice <- c(1,1,1,1,1,1)/6
# The sum(dice) =1 
plot(dice,type="h",xlab="x",ylab="PMF")
points(dice, pch=19);abline(h=0,col=3)


par(mfrow=c(1,3))
X <- c(0,1,2)
x <- c(1/4,2/4,1/4)
plot(X,x, type="h", ylim=c(0,1), xlab="x", ylab="PMF")
points(X,x, pch=19)

Y <- c(0,1,2)
y <- c(1/4,2/4,1/4)
plot(Y,y, type="h", ylim=c(0,1), xlab="y", ylab="PMF")
points(Y,y, pch=19)

Z <- c(0,1,2)
z <- c(1/4,2/4,1/4)
plot(Z,z, type="h", ylim=c(0,1), xlab="z", ylab="PMF")
points(Z,z, pch=19)
par(mfrow=c(1,1))



n <- 10  ### Define n, the number of trials
p <- 0.5   ### Define p, the probability of success
x <- 0:n  ### Creates a sequence 0, 1, 2, ..., 10
 
### dbinom function calculates the exact probability 
### of success for every x, 1:10
prob <- dbinom(x,size=n,prob=p)  
table <- rbind(x, prob)  ### Creates a table by combing rows x & prob
round(table, 1) ### Round numbers in table

par(mfrow=c(1,2))
plot(x,prob, xlim=c(-1,n+1),type="h", lwd=2, col="black", ylab="PMF")
points(x,prob, pch=19)

CDF <- pbinom(x,size=n,prob=p)
plot(x,CDF, xlim=c(-1,n+1),type="o", lwd=2, col="black", ylab="CDF")
CDF


plot(dunif(10))



dbinom(4, size=30, prob=0.2) 
sum(dbinom(4:0, size=30, prob=0.2) )

dbinom(0, size=30, prob=0.2) + 
  + dbinom(1, size=30, prob=0.2) + 
  + dbinom(2, size=30, prob=0.2) + 
  + dbinom(3, size=30, prob=0.2) + 
  + dbinom(4, size=30, prob=0.2) 

# or use the cumulative function 

pbinom(4, size=30, prob=0.2)
